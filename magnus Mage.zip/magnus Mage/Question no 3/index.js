return functionOne()
  .then(() => {
    return functionTwo()
      .then(() => ({}))
      .catch((e) => console.log("Second Error : ", e));
  })
  .catch((e) => console.log("First Error : ", e));