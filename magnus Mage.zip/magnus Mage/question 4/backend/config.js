import dotenv from "dotenv";

dotenv.config();

export default {
  MONGODB_URL:
    "mongodb+srv://admin:admin@cluster0.diy6l2j.mongodb.net/?retryWrites=true&w=majority",
};
