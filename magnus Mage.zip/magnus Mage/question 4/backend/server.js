import express from "express";
import dotenv from "dotenv";
import actorRoute from "./routes/actorRoute.js";
import bodyParser from "body-parser";
import mongoConnect from "./databaseConfig/mongodb.js";
import movieRoute from "./routes/movieRoute";



try {
  dotenv.config();
  mongoConnect();
  const app = express();




  app.use(bodyParser.json());
  app.use("/api/actor", actorRoute);
  app.use("/api/movie", movieRoute);



  app.listen(process.env.PORT || 5000, () =>
    console.log("Server started at port " + process.env.PORT || 5000)
  );
} catch (error) {
  console.error(error.message);
  process.exit(1);
}
