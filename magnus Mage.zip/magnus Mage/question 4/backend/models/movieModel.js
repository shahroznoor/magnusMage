import mongoose from 'mongoose';

const movieSchema = new mongoose.Schema({
  actor_id: { type: mongoose.Schema.Types.ObjectId },
  name: { type: String, required: true },
  status : { type: String, required: true },
});

const movieModel = mongoose.model('Movie', movieSchema);

export default movieModel;
