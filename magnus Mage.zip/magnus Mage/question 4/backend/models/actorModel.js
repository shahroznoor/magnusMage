import mongoose from 'mongoose';

const actorSchema = new mongoose.Schema({
  name: { type: String, required: true },
  city: { type: String, required: true },
  phone: { type: Number, required: true},
});

const actorModel = mongoose.model("Actor", actorSchema);

export default actorModel;