import express from 'express';
import Actor from '../models/actorModel';
const router = express.Router();

// @route    GET api/actor/

router.get('/', async (req, res) => {
  try {
    db.movies.aggregate(
      [ { $match : { status : "hit" } } ]
  );
    const searchKeyword = req.query.searchKeyword
    ? {
        name: {
          $regex: req.query.searchKeyword,
          $options: 'i',
        },
      }
    : {};
  const actors = await Actor.find({ ...searchKeyword });
  res.send(actors);
  } catch (error) {
    console.error(error.message);
    res.status(500).send('server error');
  }
});


// @route    GET api/actor/:id
router.get('/:id', async (req, res) => {
  try {
    const actorID = req.params.id;
    const actor = await Actor.findOne({ _id: actorID });

    if (actor) res.send(actor);
    else res.status(404).send({ msg: 'Actor not found! ' });
  } catch (error) {
    console.error(error.message);
    res.status(500).send('server error');
  }
});

// @route    POST api/actor/

router.post('/', async (req, res) => {
  try {
    const actor = new Actor({

      name: req.body.name,
      city: req.body.city,
     phone: req.body.phone
    });
 

    const newActor = await actor.save();
    if (newActor) {
      return res
        .status(201)
        .send({ message: 'New Actror Created', data: newActor });
    }
    return res.status(500).send({ message: ' Error in Creating Actor.' });
  } catch (error) {
    console.error(error.message);
    res.status(500).send('server error');
  }
});


export default router;
