import express from 'express';
import Movie from '../models/movieModel';


const router = express.Router();

// @route    GET api/movie/

router.get('/', async (req, res) => {
  try {
    const searchKeyword = req.query.searchKeyword
    ? {
        name: {
          $regex: req.query.searchKeyword,
          $options: 'i',
        },
      }
    : {};
  const movies = await Actor.find({ ...searchKeyword });
  res.send(movies);
  } catch (error) {
    console.error(error.message);
    res.status(500).send('server error');
  }
});


// @route    GET api/movie/:id
router.get('/:id', async (req, res) => {
  try {
    const movieID = req.params.id;
    const movie = await Actor.findOne({ _id: movieID });

    if (movie) res.send(movie);
    else res.status(404).send({ msg: 'Movie not found! ' });
  } catch (error) {
    console.error(error.message);
    res.status(500).send('server error');
  }
});

// @route    POST api/movie/

router.post('/', async (req, res) => {
  try {
    const movie = new Movie({
      actor_id : req.body.id,
      name: req.body.name,
      status: req.body.city,
    });
 

    const newMovie = await movie.save();
    if (newMovie) {
      return res
        .status(201)
        .send({ message: 'New Movie Created', data: newMovieo});
    }
    return res.status(500).send({ message: ' Error in Creating movie.' });
  } catch (error) {
    console.error(error.message);
    res.status(500).send('server error');
  }
});
export default router;
