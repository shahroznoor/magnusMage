const obj = {
    3: 5,
    5: 3,
  };
  const input = 5;
  console.log(obj[input]);