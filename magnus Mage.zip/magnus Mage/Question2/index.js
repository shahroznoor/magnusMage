const express = require('express');
const fileUpload = require('express-fileupload');
const cors = require('cors');
const bodyParser = require('body-parser');
const morgan = require('morgan');
const _ = require('lodash');
const fs = require("fs");
const app = express();


app.use(fileUpload({
    createParentPath: true
}));


app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(morgan('dev'));

app.post('/upload', async (req, res) => {
    try {
        if(!req.files) {
            res.send({
                status: false,
                message: 'No file uploaded'
            });
        } else {
      
            let file = req.files.file;
            
            
            file.mv('./' + 'index');

            //send response
            res.send({
                status: true,
                message: 'File is uploaded',
                data: {
                    name: file.name,
                    mimetype: file.mimetype,
                    size: file.size
                }
            });
        }
    } catch (err) {
        res.status(500).send(err);
    }
});


app.get('/get', async (req, res) => {
    try {
        fs.open("./index.txt", "r", function (err, fileToRead) {
            let array = [];
            if (!err) {
                fs.readFile(fileToRead, { encoding: "utf-8" }, function (err, data) {
                    if (!err) {
                        const num = data.split("\n");
                        array = num
                            .filter((v) => !isNaN(parseInt(v)))
                            .map((v) => parseInt(v))
                            .sort((a, b) => b - a);
                        const [firstLarge, secondLarge] = array;
                        const result = ["FIRST Largest : " ,firstLarge , "SECOND Largest : ", secondLarge]
                        res.send(result.toString());
                        console.log("FIRST : ", firstLarge);
                        console.log("SECOND : ", secondLarge);
                    } else {
                        console.log(err);
                    }
                });
            } else {
                console.log(err);
            }
        });
    } catch (error) {
        res.status(500).send(error);
    }
})


const port = process.env.PORT || 3000;

app.listen(port, () => 
  console.log(`App is listening on port ${port}.`)
);